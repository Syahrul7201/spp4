<!doctype html>
<html lang="en">
  <head>
	<title>Title</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS v5.0.2 -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  </head>
  <body class="overflow-hidden">

  <div class="container-fluid">
  <nav class="navbar navbar-light bg-primary mt-2">
  <div class="container-fluid">
    <a class="navbar-brand text-light fw-bold" href="#">
      <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8RDg0RDhINERUQDRIWEBcODxAOFxIXFRcWGBcSFhcYHSggGhomGxYWITMjJSkrLi4uFx8zODMtOCgvLi0BCgoKDg0OGxAQGy0lICIyLysrOC0tLS0tKy8rLS0tLTUvLS0tLS0tMi0uLS0tLS0vLS0tLy0tLS0vLS0vLSstLf/AABEIAMgAyAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAwcBBQYEAgj/xABDEAACAQIDBQQHBQUFCQAAAAAAAQIDEQQFEgYhMUFRImFxkRNCUoGhscEHMmJy0RQjgpLwJFNjssIlMzRzg6Kz0uH/xAAbAQEAAgMBAQAAAAAAAAAAAAAABQYBAwQCB//EADMRAAEDAgMECQMEAwAAAAAAAAEAAgMEEQUSMSFBYXETUYGRscHR4fAiofEUMkJiBiNy/9oADAMBAAIRAxEAPwC8QAEQABEAARAAEQABEAARa/AZlTrekUXaVKo4VYtrVCSdt/VPk+DNgU5tpm1XB53Vq0JWeik5RT3NOMbqS5p2RZezmd0sbh41aXHhOLabhLmn3dHzRzxT5nFjtR91K12GOgiZUM/Y8A/8ki9j5HvW4AB0KKQABEAARAAEQABEAARAAEQABEAARAAEQABEAOR+0TP1hcJOEX+8rxcIpcVG3al5Oy733Hh7wxpcdy301O+olbEzVxt6nsG1VPtfmKxGPxNWLvF1HGD/AAxtGPwSPZsLtBLB4qLbfoqjUaq6J27XiuPmuZzsld3MIghIQ7MNdV9UdRxOg/TkfTbL2Wt84r9NQkmk0001dNb7959nJ/Zvmn7Rl9NSd5UH6N98Uk4vyaX8J1hPMeHtDhvXyupgdTzOidq02+c0AB6WhAAEQABEAARAAEQABEAARAAEQABEAPDmmZUsPSlVryUYx8Lt8oxXNmCQBcr01rnuDWi5Oi+c2zKlhqM61V2jFcN15PlGK5tlFbQ5xVxmJqVqnPdGKd1GK4RX9cbs921m0VTG1bu8acb+jgnuS6vq3zZotJC1VV0hsNB9+K+gYLhIo2Z5Nsh14DqHmezRRWMaSXSY0nJdT+ZWF9jtdqriqXJ04z/klb/WWoVP9kFP+1YiXJYdr/ug18mWwTdEbwjtXzr/ACID9e4jeG37vSyAA61BoAAiAAIgACIAAiAAIgI7O63q1ndW4vdZ38/MkCIAAiAGl2jz+lg6WqfalJP0cE98nv3vpHvPL3hjS52gWyKJ8rwyMXJ0UueZzRwlJ1Kz4/din2pvol9eRTm0ee1sZV1VXaKv6OKvpiui6vq+Z8ZxmdbFVJVK0rt8FyS5RS5I8NiBqqwzGw/b481fMKwmOjGd2151O4cB5nU8lDpMWJrGNJyXU1mUVjGkl0mYwu0My9A3Vn/ZRgFDC1qr41aqj7oJb/OT8jvDVbOYJUcHhqdrONGLl+aXal8Wzallp2ZImt+da+YYjUfqKqSQaE7OQ2D7AIADcuJAAEQABEAARAAEQABEAARADV55m1PC0XUqb3whFPfKXTw6s8ucGgucbAL2xjpHBjBcnYFBtHntPB0nKVpTkn6OF/vPq+kUVDmOOq16sqtWTk5Pny6JLku4mzTH1MRWnUqu7k/dFcopckjx6St1dYZnbP27vVXvDMOZRs27XnU+Q4eO9RaTGkm0nzY5LqWzKLSNJsMry2rXqxp0o6nLyS5yb5I+c2wSo4irSjLX6Obi3a13HdK3de5synLm3aLz0zc+S+21+zT5yK8Gk9eTYZVMTh4PhOvTi/fJIg0k2AqunWpTXGFSMl/C0/oGusblenEkEDXcr9BDQrRnCE4O8ZxUovqmrpkxbV8rtZADkM12ujhMbKhWjqg4walT+9C64SXrdeXHma5JWRi7jbct9PTS1Di2IXIF/nf6bV14PJgcdSrwVSjOM4vnF/Brin3M9Z7BvtC0kEGx1CAAysIAAiAAIgACIAAi8+LxMKUJVKjUYxTcn/XMqPaPOJ4qu5u6it0I+zH9XzOh2+znXP8AZqb7MH+8t60+ngvn4HHaSu4lWZ3dE3Qa8T7eKt+C0PQs6Z/7nacB6nw2dah0mNJNpMaSLup7ModJ6MDgqlapCnTi5OTsl9X0R8KDbSW+/CxaeyGQLC0tc0vS1EtX4V7C+v8A8OykpzO+24a/Os7lw19e2kizfyOwDj6Df2DepMqyyll+EqOPalGlKdST9ZxV7Lu6IqOq3Jyb3ttt97ZbO3eJ0YColxqThBeep/CLKo0nVibmtc2JujR4/hcWBZ3sknkN3PPgPc9yi0jSSaRpIy6nsy7PYrayNKKw+KbUU/3c97039WXdfny+VgUcVTnHVCdOS6wnGS80UXpF31ZJQYm+NuUi4HGyhKzA4aiQyNcWk67Lg9lxbvVu51tThsNF9uNSduzCnJSd/wATX3UVFmOLnXrVKtR3dSbb/Rdy4e4+WjGk01Na+fXYAuzD8Niowchu46k+Q3D5derKM2r4WeujNp+suMZLo1zLW2a2lo4yFlaFSK7cG/jHqvkU9YkwtedOcZ05OMoO6cdzTM0tY6E9Y6vRYxHDYqxtzseND69Y8N3Ur8Bzuye0UcXT0ytGrFduK3KS9uPd8joixxyNkaHN0Kok8D4ZDHILEfO7qQAHtakAARAAEQ1ef5j+z4apU3avuw75Ph5b37jaFfbf43VWp0U91ON5fmlv+VvNnJXVHQQlw10HM+m09i7cOp+nqGtOg2nkPU2C5Kd223dtu7b33fUxpJNJjSU+6vN1FYWJNJ6srwEq9anShxlLe+i5y9yPTbuNhqUdIGgucdg2ldFsHkalL9pqLdGVqSfOS9bwXz8CwSDCYaFKnCnTVowilFeBOXGlpxBGGDt4n5sVErat1VMZDpoOA+bSuF+0uv2cNTXWU38Ev9Rwek637Qq2rGRXsUoLzvL6o5fSVuvfmqHnjbuACuGFtyUjBwv3m6i0mLE1j50nHdSGZRWMaSXSNJm6zmUOkxpJdI0mbrOZQ6RpJLCxm6zmUmW4ypQrQq0nZxd+59Yvua3Fy5TmEMRQp1qfCa3rdeLXGL8GUrpOw+zrNHCtLDyfZq74900vqvkiTw2q6OTIdHePzYoXG6MTQ9KP3M+4392verJABYlS0AARAAEXzKSSbfBLeVHmFd1a1Wo/XqSl5vciz87q6MLiJf4UkverfUq1xK9jkpBYzmfL1ViwJgDXv5DzUWkxpJdJjSQGZT+ZRWO42Cy3TTqV5LfUemH5Vxfve7+E4yMG2kuLe4tnL8MqVKnTXqQS9/N+dyYwaHPMXn+Pifa6h8aqCyERj+XgPgXqABaFVlVm189WOrvo4ryjFfQ0uk3W1Ef7biP+Y/oaqxSKg/7n/wDTvFX2lNoGD+rfAKHSNJLY+dJquujMo9JjSS6TGkzdZzKKxixtMryetiJNUo3t95vdFdzfU8WIw8oSlCacZRdpJ7mmbMjg0OI2HesCVpcWAi41G8Lz6TGkm0mNJ5utmZRaSTBVpU6tOpHjCcZLxTuNJixnMRolwdVddCqpwhOPCcFJeDV0TGp2Xq68DhX/AIen+VuP0NsXWN+dod1gHvF186lj6ORzOokdxQAHta0AARanan/gq/hD/PErjSWXtBS1YTEL8F/5Wn9CubFVx24naf6+BPqrJgzv9Dh/byHoodI0kmkxpIW6l8y9ORU74rDJ/wB9C/uaZaRV2VVVTxFGb4Rqxb8L7/gWiWjAiOifz8vyq9jRJezl88kABOKFVcbaYbTjJvlUjGS8rP4xZodJYu1WUOvTjOCvOney9qL4rx5+ZwE6bTaaaae9NWaKdicJinJOjto7dfurhhtQJYGgatFj2bFFpMaSXQzb5dsziatm4+jj7VTs+UeLOSKN8rssYJPBdkszYm5nmw4rRKB0+R7IzqWnibwjyjwm/wD1XxOmyfIKGH7SWqftTS3flXL5m5LBSYQG/VNt4DTtO/w5hQVXjRcMsGzidewbvHkV58Lh4UoRhTjGMY8FH+t7NFtXkar03Upr97BcvXivV8enkdKCXlgZLGY3DZ4cuShoZ5IpBI07fHnzVK6D50nQbXZeqOKlpSUai1x7r3uvNM0ukpUrHRPLHag2V5hmErA9uhF1BpGklsFE8ZluzKzdjV/s/Df9T/ySN2a3IaHo8Jhov+6i34y7T+Zsi70zS2FjTuAH2CoVW4Pne4b3E/coADcudAAEUNempxnF8JJp+9WKzq0nGUovc4tp+KLSOJ2qwOis5pdmr/m9ZfX3kDj0BdE2UfxNjyPuB3qWwmbK90Z37e728FoNJ86SaxjSVW6sF1FpO22bzmNSEaVR2qRVlf10uHvON0mLHXRVr6WTO3bfUda56mnZUMyu7D1K1AcFg9osRTtqkqi6VN78+Jt8HtXB2VaEod8HrXlx+ZaYsYpZNTlPH1Fx91AyYbOzQX5emq6Y81bB0pu86dKb6ypxk/NmcNiYVI6qcoyXc/g+h6CS+l46we0Lh+ph3g9xXnoYSnD7lOlD8kIx+R6ADIAAsFgkk3KAAysIAeTH42nQg51HZLglxk+iXNnlzg0FzjYBZa0uNgLkrktvrOrQXNUm34Nu3yZymk2GaYuVerOpLdqe5eylwR5NJSKycTTukGh0V0o4zDA2M6gKHSezJsC6+IpU+TktXdFb5PyuQWO42Myr0dN1prtVFaN+UOvvfwSNlBAaiYN3anl76LFbVCCEv36Dn7arpjIBdVS0AARAAEQ8Ga4FVqUoO1+MX0a/qx7weJGNkaWOFwdhXpjixwc3UKtKtJxlKMk04uzT5HxY7TPMnVZaqdlUS8FNdH395x1SnKMnGSaae9NWaKLXUL6V9jtadD1+6s1NUtnbca7x1eyjsNJ9A4brquo7CxILC6zdfeDxdSjNTpyafPo10tzR3WU5hGvT1Lc1unHo/wBDgbGwyPGujXjK/Zk9M/fz93ElsLxA08gY4/QdeHEefDiuCupWzMzAfUNOPD0XfAAuqraAHL7U5rKL9DTdrx/eNcd/CPl8znqqplNGZH/krdTwOmfkb+F6c32jp0rxp2qT5+zHxfN9yONxuLqVp6qsnJ9/BdyXI+dJjSUyrxCWpP1mw3Aae54nssrPTUsVOPp169/sorDSS6TeZJs9Ko1OteMOS4Ofh0XeaqeCSd+SMXPhz6lvlnZE3M82HzRQ7NZI601OomqcXv8Axvou7qd7YjpU4xioxSSirJLgiUulFRtpo8o2k6nr9hu/KqtXVOqH5jsA0HV7negAOxcqAAIgACIAAiGvzHLKVZdtWkuElua/VGwB4kjbI0teLg9a9Me5hzNNiuHx2z9endxXpI9YLf748TWFlnkxWBpVf95CMu+2/wA1vK/U/wCPtJvC63A7R36+KlYsVIFpG35en4VemTra+zFF/clUh5TX6/E8VXZWfqVIPxTj8rkU/Bqxujb8iPMg/ZdzcQgd/K3Nc8ZNxPZrELgqb8J2+ZE9ncV7C/nh+pzOw+qGsTu4nwW4VUO547wurymup4ejL8CT8Y7n8j3Go2ew9SlScKsdLU24707p+D638zbl5pXOdAwvBBsL3FjfQ7Dt1VZnAErg3S+yyFc5jU11qkvaqSfx3FjHIUNma0nepKELvh99+S3fEi8agmnEbImk6k/a207N53ruw2WOPM55tp88Fz+k9WCyyrWdqcX3t7kvE6zCbPUIb5J1H+Ph5L63NtCKSSSSS4JbrHHTYC87Z3W4Dae/Tx5rpmxVo2Ri/P0WkyvZ2nTtKpapLw7K8Fz95vgCxQU8cDckYsPmvWoeWZ8rszzdAAblrQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEX/9k=" alt="" width="30" height="30" class="d-inline-block align-text-top">
      CODEIGNETER 3
    </a>
  </div>
</nav>

<div class="row mt-2" >
	<div class="col-3">
<div class="card bg-primary fw-bold" style="height:500px">
	<i class="card-header text-light fw-bold text-center mb-2">SIDEBAR</i>
<a href="<?php echo site_url('Welcome/DataSiswa'); ?>" class="btn btn-light border-none fw-bold mx-1"> DATA SISWA</a> <hr>
<a href="<?php echo site_url('Welcome/Logout'); ?>" class="btn btn-light border-none fw-bold mx-1"> LOGOUT</a>

	
	</div>
	</div>
	<div class="col">
	<div class="card bg-primary" style="height:500px">



	<?php $this->load->view($content); ?>
	</div>
</div>
</div>
</div>


<script src="https://kit.fontawesome.com/a7293e9119.js" crossorigin="anonymous"></script>
	  
	<!-- Bootstrap JavaScript Libraries -->
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  </body>
</html>



<!--
<html>
	<head>
		<title>Backend System</title>
	</head>
	<body>
		<table width="800px" height="600px" border="1px" align="center">
			<tr height="100px">
				<td>
					<a href="<?php echo site_url('Welcome/DataSiswa'); ?>">Data Siswa</a>
					<a href="<?php echo site_url('Welcome/Logout'); ?>">Logout</a>
				</td>
			</tr>
			<tr height="500px">
				<td>
					<?php $this->load->view($content); ?>
				</td>
			</tr>
		</table>
	</body>
	
</html>