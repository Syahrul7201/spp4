<div class="card-header fw-bold text-light text-center">
		SELAMAT DATANG DI WEB


	</div>

<div class="my-auto">
<h1 class="fw-bold text-light text-center"> HI </h1>
</div>