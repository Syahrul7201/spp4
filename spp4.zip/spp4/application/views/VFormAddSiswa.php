<div class="card-header text-light fw-bold border-3 border-light">
<i class="fas fa-plus"></i> Form Tambah Siswa
</div>


<div class="card-body">
	<div class="card top-50 start-50 translate-middle" style="width:300px">
	
	<div class="card-header mb-3">
		<i class="fas fa-plus"></i>Tambah Siswa
	</div>
	
<div class="card-body p-2">
<form action="<?php echo site_url('Welcome/AddDataSiswa'); ?>" method="post">
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon3">Nis</span>
  <input name="nis" type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon3">Nama</span>
  <input name="nama" type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon3">Alamat</span>
  <input name="alamat" type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3">
</div>  
  
<div class="card">
<input class="btn btn-success d-flex" name="simpan" type="submit"></input>
</div>
</form>
</div>
</div>

</div>



<script src="https://kit.fontawesome.com/a7293e9119.js" crossorigin="anonymous"></script>