<div class="card-header fw-bold text-white border-light border-3">
  <div class="row">
    <div class="col" >
<i class="fas fa-user" ></i> Data Siswa
</div>


<div class="col">
<div class="d-flex justify-content-end">
<a class="btn btn-success" href="<?php echo site_url('Welcome/VFormAddSiswa'); ?>"><i class="fas fa-plus"></i> Tambah Data</a>


</div>
</div>
</div>





</div>

<div class="card mx-2 my-2 overflow-auto" style="max-height: 450px">
<table class="table table table-striped">
  <thead>
    <tr class="bg-primary fw-bold text-light text-center">
      <th scope="col" style="width:10px;">No</th>
      <th scope="col" style="width:px;">Nis</th>
      <th scope="col" style="width:px;">Nama</th>
      <th scope="col" style="width:px;">Alamat</th>
      <th scope="col" style="width:120px;">Tools</th>
    </tr>
  </thead>
  <tbody>
  <?php
	if(!empty($DataSiswa))
	{
 $no = 1;  
		foreach($DataSiswa as $ReadDS)
		{
	?>
<tr>
    <td><?php echo $no++; ?></td>
		<td><?php echo $ReadDS->nis; ?></td>
		<td><?php echo $ReadDS->nama; ?></td>
		<td><?php echo $ReadDS->alamat; ?></td>
		<td class="text-center">
			<a class="btn btn-warning" href="<?php echo site_url('Welcome/DataSiswa/'.$ReadDS->nis.'/view') ?>"><i class="fas fa-pen"></i></a>
			<a class="btn btn-danger" href="<?php echo site_url('Welcome/DeleteDataSiswa/'.$ReadDS->nis) ?>"><i class="fas fa-trash"></i></a>
		</td>
	</tr>

	<?php		
		}
	}
	?>





  </tbody>
</table>




</div>











<!--
<table border="1px">
	<tr>
		<td colspan="4">
			<a href="<?php echo site_url('Welcome/VFormAddSiswa'); ?>">Add</a>
		</td>
	</tr>
	<tr>
		<th>NIS</th>
		<th>Nama</th>
		<th>Alamat</th>
		<th>Tools</th>
	</tr>
	<?php
	if(!empty($DataSiswa))
	{
		foreach($DataSiswa as $ReadDS)
		{
	?>

	<tr>
		<td><?php echo $ReadDS->nis; ?></td>
		<td><?php echo $ReadDS->nama; ?></td>
		<td><?php echo $ReadDS->alamat; ?></td>
		<td>
			<a href="<?php echo site_url('Welcome/DataSiswa/'.$ReadDS->nis.'/view') ?>">Update</a>
			<a href="<?php echo site_url('Welcome/DeleteDataSiswa/'.$ReadDS->nis) ?>">Delete</a>
		</td>
	</tr>

	<?php		
		}
	}
	?>
</table>











-->
<script src="https://kit.fontawesome.com/a7293e9119.js" crossorigin="anonymous"></script>